﻿// The MIT License (MIT)
//
// Copyright (c) 2013 Marek Fiser [malsys@marekfiser.cz] - malsys.cz
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.

namespace Malsys.BitmapRenderers.Png.Chunks {
	public class ChunkTEXt {

		public static readonly string AuthorKeyword = "Author";
		public static readonly string DescriptionKeyword = "Description";
		public static readonly string CopyrightKeyword = "Copyright";
		public static readonly string CreationTimeKeyword = "Creation Time";
		public static readonly string SoftwareKeyword = "Software";
		public static readonly string DisclaimerKeyword = "Disclaimer";
		public static readonly string WarningKeyword = "Warning";
		public static readonly string SourceKeyword = "Source";
		public static readonly string CommentKeyword = "Comment";

		public static string PredefinedKwToString(PredefinedKeyword predefinedKw) {
			switch (predefinedKw) {
				case PredefinedKeyword.Author: return AuthorKeyword;
				case PredefinedKeyword.Description: return DescriptionKeyword;
				case PredefinedKeyword.Copyright: return CopyrightKeyword;
				case PredefinedKeyword.CreationTime: return CreationTimeKeyword;
				case PredefinedKeyword.Software: return SoftwareKeyword;
				case PredefinedKeyword.Disclaimer: return DisclaimerKeyword;
				case PredefinedKeyword.Warning: return WarningKeyword;
				case PredefinedKeyword.Source: return SourceKeyword;
				case PredefinedKeyword.Comment: return CommentKeyword;
				default: return null;
			}
		}


		public static readonly string Name = "tEXt";
		public uint Length { get { return (uint)keyword.Length + (uint)text.Length + 1u; } }

		public string Keyword {
			get { return keyword; }
			set { keyword = value.Replace("\r", ""); }
		}
		private string keyword;

		public string Text {
			get { return text; }
			set { text = value.Replace("\r", ""); }
		}
		private string text;


		public ChunkTEXt(string keyword, string text) {
			Keyword = keyword;
			Text = text;
		}

		public ChunkTEXt(PredefinedKeyword predefinedKw, string text) {
			keyword = PredefinedKwToString(predefinedKw);
			Text = text;
		}


		public enum PredefinedKeyword {
			Author,
			Description,
			Copyright,
			CreationTime,
			Software,
			Disclaimer,
			Warning,
			Source,
			Comment,
		}

	}
}
